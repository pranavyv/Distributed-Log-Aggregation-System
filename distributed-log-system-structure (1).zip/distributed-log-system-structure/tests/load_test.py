import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
CLIENT_PATH = ROOT / "client" / "log_client.py"


def main(client_count=10, duration_seconds=10):
    processes = []

    for index in range(client_count):
        env = os.environ.copy()
        env["PYTHONPATH"] = str(ROOT) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        env["LOG_SERVER_NAME"] = f"load-client-{index + 1}"
        env["LOG_SEND_INTERVAL_SECONDS"] = "0.1"
        processes.append(
            subprocess.Popen(
                [sys.executable, str(CLIENT_PATH)],
                cwd=str(ROOT),
                env=env,
            )
        )

    print(f"Started {client_count} clients for {duration_seconds} seconds.")

    try:
        time.sleep(duration_seconds)
    finally:
        for process in processes:
            process.terminate()
        for process in processes:
            process.wait(timeout=5)

    print("Load test complete.")


if __name__ == "__main__":
    main()
