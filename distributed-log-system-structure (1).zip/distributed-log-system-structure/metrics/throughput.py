import threading
import time

from storage.database import update_metrics


class ThroughputTracker:
    def __init__(self):
        self._lock = threading.Lock()
        self._received = 0
        self._processed = 0
        self._dropped = 0
        self._parse_errors = 0
        self._handshake_failures = 0
        self._active_connections = 0
        self._window_started_at = time.time()

    def mark_received(self):
        with self._lock:
            self._received += 1

    def mark_processed(self, count=1):
        with self._lock:
            self._processed += count

    def mark_dropped(self):
        with self._lock:
            self._dropped += 1

    def mark_parse_error(self):
        with self._lock:
            self._parse_errors += 1

    def mark_handshake_failure(self):
        with self._lock:
            self._handshake_failures += 1

    def change_active_connections(self, delta):
        with self._lock:
            self._active_connections = max(0, self._active_connections + delta)

    def snapshot_and_reset(self):
        with self._lock:
            now = time.time()
            elapsed = max(now - self._window_started_at, 1e-9)
            snapshot = {
                "received_per_sec": self._received / elapsed,
                "processed_per_sec": self._processed / elapsed,
                "dropped": self._dropped,
                "parse_errors": self._parse_errors,
                "handshake_failures": self._handshake_failures,
                "active_connections": self._active_connections,
                "window_seconds": elapsed,
            }
            self._received = 0
            self._processed = 0
            self._window_started_at = now
            return snapshot


tracker = ThroughputTracker()


def log_received():
    tracker.mark_received()


def log_processed(count=1):
    tracker.mark_processed(count)


def log_dropped():
    tracker.mark_dropped()


def log_parse_error():
    tracker.mark_parse_error()


def log_handshake_failure():
    tracker.mark_handshake_failure()


def log_active_connection_change(delta):
    tracker.change_active_connections(delta)


def report():
    snapshot = tracker.snapshot_and_reset()
    update_metrics(
        snapshot["received_per_sec"],
        snapshot["processed_per_sec"],
        snapshot.get("queue_size", 0),
        snapshot["dropped"],
        snapshot["parse_errors"],
        snapshot["handshake_failures"],
        snapshot["active_connections"],
    )
    print(
        "Received/sec: {:.2f} | Processed/sec: {:.2f} | Dropped: {} | Parse errors: {} | Handshake failures: {} | Active connections: {}".format(
            snapshot["received_per_sec"],
            snapshot["processed_per_sec"],
            snapshot["dropped"],
            snapshot["parse_errors"],
            snapshot["handshake_failures"],
            snapshot["active_connections"],
        )
    )


def report_with_queue(queue_size):
    snapshot = tracker.snapshot_and_reset()
    snapshot["queue_size"] = queue_size
    update_metrics(
        snapshot["received_per_sec"],
        snapshot["processed_per_sec"],
        queue_size,
        snapshot["dropped"],
        snapshot["parse_errors"],
        snapshot["handshake_failures"],
        snapshot["active_connections"],
    )
    print(
        "Received/sec: {:.2f} | Processed/sec: {:.2f} | Queue size: {} | Dropped: {} | Parse errors: {} | Handshake failures: {} | Active connections: {}".format(
            snapshot["received_per_sec"],
            snapshot["processed_per_sec"],
            queue_size,
            snapshot["dropped"],
            snapshot["parse_errors"],
            snapshot["handshake_failures"],
            snapshot["active_connections"],
        )
    )
