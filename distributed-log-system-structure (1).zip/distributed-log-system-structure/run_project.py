import os
import subprocess
import sys
import time
import webbrowser
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable


def start_process(name, script_path, working_dir, extra_env=None):
    env = os.environ.copy()
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(ROOT) if not existing else f"{ROOT}{os.pathsep}{existing}"
    if extra_env:
        env.update(extra_env)

    process = subprocess.Popen(
        [PYTHON, str(script_path)],
        cwd=str(working_dir),
        env=env,
    )

    print(f"Started {name} (PID {process.pid})")
    return process


def main():
    processes = [
        start_process("server", ROOT / "server" / "server_main.py", ROOT),
        start_process(
            "client-1",
            ROOT / "client" / "log_client.py",
            ROOT / "client",
            {"LOG_SERVER_NAME": "client1"},
        ),
        start_process(
            "client-2",
            ROOT / "client" / "log_client.py",
            ROOT / "client",
            {"LOG_SERVER_NAME": "client2"},
        ),
        start_process("dashboard", ROOT / "dashboard" / "app.py", ROOT),
    ]

    dashboard_url = "http://127.0.0.1:5000"
    time.sleep(2)
    webbrowser.open(dashboard_url)

    print(f"Dashboard: {dashboard_url}")
    print("Press Ctrl+C in this window to stop everything.")
    print("Client/server traffic is secured with TLS using certs/server.crt and certs/server.key.")

    try:
        while True:
            time.sleep(1)
            for process in processes:
                if process.poll() is not None:
                    raise RuntimeError(
                        f"A process exited early (PID {process.pid}, code {process.returncode})."
                    )
    except KeyboardInterrupt:
        print("\nStopping processes...")
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()

        for process in processes:
            if process.poll() is None:
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()


if __name__ == "__main__":
    main()
