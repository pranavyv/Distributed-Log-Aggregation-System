import queue

from utils.config import QUEUE_SIZE


log_queue = queue.Queue(maxsize=QUEUE_SIZE)
