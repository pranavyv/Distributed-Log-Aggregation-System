# Team Division for 3 People

This project can be split cleanly into 3 workstreams with low merge conflict and clear ownership.

## Person 1: Client + Secure Networking

Primary responsibility:
- all client-side log generation and TLS socket communication
- server-side socket acceptance and TLS handshake handling
- connection lifecycle and certificate setup

Own these files:
- `client/log_client.py`
- `client/client_config.py`
- `server/receiver.py`
- `scripts/generate_certs.py`
- `certs/` for demo setup only

Main tasks:
- make client connection/reconnection behavior solid
- validate TLS setup and certificate loading
- improve socket error handling and connection cleanup
- test multiple simultaneous client connections
- document how secure communication works

Deliverables:
- reliable TLS client-server communication
- stable multi-client connection handling
- certificate generation/setup instructions

## Person 2: Log Processing Pipeline + Storage

Primary responsibility:
- ingestion queue, parsing, ordering, processing, and database persistence
- server-side pipeline performance and correctness

Own these files:
- `queue_system/log_queue.py`
- `server/worker.py`
- `server/processor.py`
- `ordering/time_ordering.py`
- `storage/database.py`
- `storage/schema.sql`
- `utils/log_parser.py`
- `utils/config.py` for pipeline-related settings

Main tasks:
- maintain queue behavior under load
- parse incoming logs safely
- ensure timestamp ordering works correctly
- flush processed logs into SQLite
- tune worker count, queue size, and ordering grace window

Deliverables:
- correct end-to-end pipeline from raw log line to stored record
- stable ordering and batching behavior
- database schema and persistence logic

## Person 3: Dashboard + Metrics + Testing + Documentation

Primary responsibility:
- monitoring, presentation, performance evaluation, and project packaging

Own these files:
- `dashboard/app.py`
- `dashboard/templates/index.html`
- `metrics/throughput.py`
- `tests/load_test.py`
- `docs/PERFORMANCE_EVALUATION.md`
- `README.md`
- `run_project.py`

Main tasks:
- build and improve the Flask dashboard
- expose useful live metrics
- run load tests and record observations
- polish README, architecture, setup, and demo flow
- make startup/testing workflow easy for the team

Deliverables:
- working dashboard for logs and metrics
- performance test results and analysis
- final presentation-ready documentation

## Shared Integration Rules

- `utils/config.py` should be changed carefully because it affects everyone.
- Person 1 and Person 2 should agree on message format: `timestamp|server_name|level|message`.
- Person 2 and Person 3 should agree on what metrics are stored and shown.
- Person 3 should test the full flow after merges from Person 1 and Person 2.

## Best Working Order

1. Person 1 finishes secure client-server communication.
2. Person 2 connects the queue, parser, ordering, and database pipeline.
3. Person 3 builds dashboard, runs load tests, and completes documentation.

## Recommended Team Roles

- Person 1: Networking / Security lead
- Person 2: Backend / Processing lead
- Person 3: Dashboard / Testing / Documentation lead
