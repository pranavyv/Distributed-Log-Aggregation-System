# Performance Evaluation Guide

Use this file during your final submission/demo to record observations from the secure socket system.

## Suggested Experiments

1. Baseline run with 1 client for 30 seconds
2. Moderate load with 10 clients for 30 seconds
3. Higher load with 25 clients for 30 seconds
4. Invalid traffic test to show parse-error handling
5. Wrong-certificate or plaintext connection test to show TLS handshake failure handling

## Metrics To Capture

- received logs per second
- processed logs per second
- queue size
- dropped logs
- parse errors
- active connections
- TLS handshake failures

## Observation Template

| Scenario | Clients | Send Interval | Received/sec | Processed/sec | Queue Size | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| Baseline | 1 | 0.5s | | | | |
| Moderate load | 10 | 0.1s | | | | |
| Higher load | 25 | 0.1s | | | | |

## Sample Results From This Repo

| Scenario | Clients | Send Interval | Received/sec | Processed/sec | Queue Size | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| Baseline | 1 | 0.5s | 2.00 | 2.00 | 0 | Stable TLS connection, no dropped logs |
| Moderate load | 10 | 0.1s | 99.86 | 98.86 | 0 | 10 concurrent TLS clients, no parse or handshake failures |

These measurements were captured locally on March 26, 2026 while the server was running and the metrics table was sampled live.

## Discussion Prompts

- How does throughput scale as clients increase?
- Does queue size remain stable or grow continuously?
- At what point do dropped logs appear?
- How does TLS impact the design and operational stability?
- What optimizations were added after testing?
