import sqlite3
import threading
from datetime import datetime

from utils.config import DB_FILE, RECENT_LOG_LIMIT


class LogDatabase:
    def __init__(self, db_path):
        self._connection = sqlite3.connect(db_path, check_same_thread=False)
        self._connection.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        self._initialize()

    def _initialize(self):
        with self._lock:
            self._connection.execute(
                """
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER NOT NULL,
                    server TEXT NOT NULL,
                    level TEXT NOT NULL,
                    message TEXT NOT NULL
                )
                """
            )
            self._connection.execute(
                """
                CREATE TABLE IF NOT EXISTS system_metrics (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    received_per_sec REAL NOT NULL,
                    processed_per_sec REAL NOT NULL,
                    queue_size INTEGER NOT NULL,
                    dropped_logs INTEGER NOT NULL DEFAULT 0,
                    parse_errors INTEGER NOT NULL DEFAULT 0,
                    handshake_failures INTEGER NOT NULL DEFAULT 0,
                    active_connections INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                )
                """
            )
            self._ensure_column("system_metrics", "dropped_logs", "INTEGER NOT NULL DEFAULT 0")
            self._ensure_column("system_metrics", "parse_errors", "INTEGER NOT NULL DEFAULT 0")
            self._ensure_column("system_metrics", "handshake_failures", "INTEGER NOT NULL DEFAULT 0")
            self._ensure_column("system_metrics", "active_connections", "INTEGER NOT NULL DEFAULT 0")
            self._connection.execute(
                """
                INSERT OR IGNORE INTO system_metrics (
                    id,
                    received_per_sec,
                    processed_per_sec,
                    queue_size,
                    dropped_logs,
                    parse_errors,
                    handshake_failures,
                    active_connections,
                    updated_at
                ) VALUES (1, 0, 0, 0, 0, 0, 0, 0, '')
                """
            )
            self._connection.commit()

    def _ensure_column(self, table_name, column_name, column_definition):
        columns = {
            row["name"]
            for row in self._connection.execute(f"PRAGMA table_info({table_name})").fetchall()
        }
        if column_name not in columns:
            self._connection.execute(
                f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_definition}"
            )

    def insert_logs(self, logs):
        if not logs:
            return

        rows = [
            (log["timestamp"], log["server"], log["level"], log["message"])
            for log in logs
        ]

        with self._lock:
            self._connection.executemany(
                "INSERT INTO logs (timestamp, server, level, message) VALUES (?, ?, ?, ?)",
                rows,
            )
            self._connection.commit()

    def get_recent_logs(self, limit=RECENT_LOG_LIMIT):
        with self._lock:
            rows = self._connection.execute(
                """
                SELECT id, timestamp, server, level, message
                FROM logs
                ORDER BY timestamp DESC, id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()

        return [
            {
                "id": row["id"],
                "timestamp": row["timestamp"],
                "formatted_timestamp": datetime.fromtimestamp(row["timestamp"]).strftime(
                    "%Y-%m-%d %H:%M:%S"
                ),
                "server": row["server"],
                "level": row["level"],
                "message": row["message"],
            }
            for row in rows
        ]

    def update_metrics(
        self,
        received_per_sec,
        processed_per_sec,
        queue_size,
        dropped_logs,
        parse_errors,
        handshake_failures,
        active_connections,
    ):
        with self._lock:
            self._connection.execute(
                """
                UPDATE system_metrics
                SET received_per_sec = ?,
                    processed_per_sec = ?,
                    queue_size = ?,
                    dropped_logs = ?,
                    parse_errors = ?,
                    handshake_failures = ?,
                    active_connections = ?,
                    updated_at = ?
                WHERE id = 1
                """,
                (
                    received_per_sec,
                    processed_per_sec,
                    queue_size,
                    dropped_logs,
                    parse_errors,
                    handshake_failures,
                    active_connections,
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                ),
            )
            self._connection.commit()

    def get_metrics(self):
        with self._lock:
            row = self._connection.execute(
                """
                SELECT received_per_sec, processed_per_sec, queue_size, dropped_logs,
                       parse_errors, handshake_failures, active_connections, updated_at
                FROM system_metrics
                WHERE id = 1
                """
            ).fetchone()

        if row is None:
            return {
                "received_per_sec": 0.0,
                "processed_per_sec": 0.0,
                "queue_size": 0,
                "dropped_logs": 0,
                "parse_errors": 0,
                "handshake_failures": 0,
                "active_connections": 0,
                "updated_at": "",
            }

        return {
            "received_per_sec": row["received_per_sec"],
            "processed_per_sec": row["processed_per_sec"],
            "queue_size": row["queue_size"],
            "dropped_logs": row["dropped_logs"],
            "parse_errors": row["parse_errors"],
            "handshake_failures": row["handshake_failures"],
            "active_connections": row["active_connections"],
            "updated_at": row["updated_at"],
        }


database = LogDatabase(DB_FILE)


def insert_logs(logs):
    database.insert_logs(logs)


def get_logs(limit=RECENT_LOG_LIMIT):
    return database.get_recent_logs(limit)


def update_metrics(
    received_per_sec,
    processed_per_sec,
    queue_size,
    dropped_logs,
    parse_errors,
    handshake_failures,
    active_connections,
):
    database.update_metrics(
        received_per_sec,
        processed_per_sec,
        queue_size,
        dropped_logs,
        parse_errors,
        handshake_failures,
        active_connections,
    )


def get_metrics():
    return database.get_metrics()
