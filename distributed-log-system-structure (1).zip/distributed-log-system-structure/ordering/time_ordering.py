import heapq
import itertools
import threading

from utils.config import ORDERING_GRACE_SECONDS


class TimeOrderedBuffer:
    def __init__(self, grace_seconds):
        self.grace_seconds = grace_seconds
        self._heap = []
        self._lock = threading.Lock()
        self._sequence = itertools.count()
        self._max_timestamp_seen = None

    def add_log(self, log_record):
        with self._lock:
            timestamp = log_record["timestamp"]
            if self._max_timestamp_seen is None or timestamp > self._max_timestamp_seen:
                self._max_timestamp_seen = timestamp

            heapq.heappush(
                self._heap,
                (timestamp, next(self._sequence), log_record),
            )

    def pop_ready_logs(self):
        ready_logs = []

        with self._lock:
            if self._max_timestamp_seen is None:
                return ready_logs

            watermark = self._max_timestamp_seen - self.grace_seconds

            while self._heap and self._heap[0][0] <= watermark:
                ready_logs.append(heapq.heappop(self._heap)[2])

        return ready_logs

    def flush_all(self):
        flushed_logs = []

        with self._lock:
            while self._heap:
                flushed_logs.append(heapq.heappop(self._heap)[2])

        return flushed_logs

    def size(self):
        with self._lock:
            return len(self._heap)


ordered_buffer = TimeOrderedBuffer(ORDERING_GRACE_SECONDS)
