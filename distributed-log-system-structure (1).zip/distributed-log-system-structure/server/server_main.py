import threading
import time

from metrics.throughput import report_with_queue
from queue_system.log_queue import log_queue
from server.processor import process_ready_logs
from server.receiver import start_receiver
from server.worker import worker
from utils.config import METRICS_REPORT_INTERVAL_SECONDS, WORKER_COUNT


def start_workers(stop_event):
    threads = []
    for index in range(WORKER_COUNT):
        thread = threading.Thread(
            target=worker,
            args=(stop_event,),
            daemon=True,
            name=f"worker-{index + 1}",
        )
        thread.start()
        threads.append(thread)
    return threads


def main():
    stop_event = threading.Event()
    worker_threads = []

    receiver_thread = threading.Thread(
        target=start_receiver,
        args=(stop_event,),
        daemon=True,
        name="udp-receiver",
    )
    processor_thread = threading.Thread(
        target=process_ready_logs,
        args=(stop_event,),
        daemon=True,
        name="log-processor",
    )

    receiver_thread.start()
    processor_thread.start()
    worker_threads = start_workers(stop_event)

    print("Secure distributed log aggregation server is running.")

    try:
        while True:
            time.sleep(METRICS_REPORT_INTERVAL_SECONDS)
            report_with_queue(log_queue.qsize())
    except KeyboardInterrupt:
        print("\nStopping server...")
    finally:
        stop_event.set()
        receiver_thread.join(timeout=2)
        processor_thread.join(timeout=2)
        for thread in worker_threads:
            thread.join(timeout=2)


if __name__ == "__main__":
    main()
