import queue
import socket
import ssl
import threading

from metrics.throughput import (
    log_active_connection_change,
    log_dropped,
    log_handshake_failure,
    log_received,
)
from queue_system.log_queue import log_queue
from utils.config import (
    CLIENT_READ_BUFFER_SIZE,
    SERVER_HOST,
    SERVER_PORT,
    SOCKET_BACKLOG,
    SOCKET_TIMEOUT_SECONDS,
    TLS_CERT_FILE,
    TLS_KEY_FILE,
)


def enqueue_log_line(log_line):
    log_received()
    try:
        log_queue.put_nowait(log_line)
    except queue.Full:
        log_dropped()
        print("Warning: ingestion queue is full, dropping log.")


def handle_client_connection(client_socket, client_address, stop_event=None):
    log_active_connection_change(1)
    print(f"Accepted secure client connection from {client_address[0]}:{client_address[1]}")
    buffer = ""

    try:
        while stop_event is None or not stop_event.is_set():
            try:
                data = client_socket.recv(CLIENT_READ_BUFFER_SIZE)
            except socket.timeout:
                continue
            except (ConnectionError, OSError, ssl.SSLError) as exc:
                print(f"Connection with {client_address[0]}:{client_address[1]} closed: {exc}")
                break

            if not data:
                break

            buffer += data.decode("utf-8", errors="replace")

            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                stripped = line.strip()
                if stripped:
                    enqueue_log_line(stripped)
    finally:
        if buffer.strip():
            enqueue_log_line(buffer.strip())
        log_active_connection_change(-1)
        try:
            client_socket.close()
        except OSError:
            pass


def create_tls_context():
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(certfile=TLS_CERT_FILE, keyfile=TLS_KEY_FILE)
    return context


def start_receiver(stop_event=None):
    tls_context = create_tls_context()
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind((SERVER_HOST, SERVER_PORT))
    listener.listen(SOCKET_BACKLOG)
    listener.settimeout(SOCKET_TIMEOUT_SECONDS)

    client_threads = []
    print(f"TLS receiver listening on {SERVER_HOST}:{SERVER_PORT}")

    try:
        while stop_event is None or not stop_event.is_set():
            try:
                client_socket, client_address = listener.accept()
            except socket.timeout:
                continue
            except OSError:
                if stop_event is not None and stop_event.is_set():
                    break
                raise

            try:
                secure_socket = tls_context.wrap_socket(client_socket, server_side=True)
                secure_socket.settimeout(SOCKET_TIMEOUT_SECONDS)
            except ssl.SSLError as exc:
                log_handshake_failure()
                print(f"TLS handshake failed from {client_address[0]}:{client_address[1]}: {exc}")
                client_socket.close()
                continue

            thread = threading.Thread(
                target=handle_client_connection,
                args=(secure_socket, client_address, stop_event),
                daemon=True,
                name=f"client-{client_address[0]}:{client_address[1]}",
            )
            thread.start()
            client_threads.append(thread)
    finally:
        try:
            listener.close()
        except OSError:
            pass

        for thread in client_threads:
            thread.join(timeout=2)
