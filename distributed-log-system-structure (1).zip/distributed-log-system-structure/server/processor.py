import time

from metrics.throughput import log_processed
from ordering.time_ordering import ordered_buffer
from storage.database import insert_logs
from utils.config import PROCESSOR_POLL_INTERVAL_SECONDS


def process_ready_logs(stop_event=None):
    while stop_event is None or not stop_event.is_set():
        ready_logs = ordered_buffer.pop_ready_logs()
        if ready_logs:
            insert_logs(ready_logs)
            log_processed(len(ready_logs))
        else:
            time.sleep(PROCESSOR_POLL_INTERVAL_SECONDS)

    remaining_logs = ordered_buffer.flush_all()
    if remaining_logs:
        insert_logs(remaining_logs)
        log_processed(len(remaining_logs))
