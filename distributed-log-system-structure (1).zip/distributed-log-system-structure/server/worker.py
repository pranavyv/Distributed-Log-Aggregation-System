import queue

from metrics.throughput import log_parse_error
from ordering.time_ordering import ordered_buffer
from queue_system.log_queue import log_queue
from utils.log_parser import parse_log


def worker(stop_event=None):
    while stop_event is None or not stop_event.is_set():
        try:
            raw_log = log_queue.get(timeout=0.5)
        except queue.Empty:
            continue

        try:
            parsed_log = parse_log(raw_log)
            ordered_buffer.add_log(parsed_log)
        except (ValueError, IndexError):
            log_parse_error()
        finally:
            log_queue.task_done()
