from flask import Flask, render_template

from storage.database import get_logs, get_metrics
from utils.config import DASHBOARD_HOST, DASHBOARD_PORT


app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html", logs=get_logs(), metrics=get_metrics())


if __name__ == "__main__":
    app.run(host=DASHBOARD_HOST, port=DASHBOARD_PORT)
