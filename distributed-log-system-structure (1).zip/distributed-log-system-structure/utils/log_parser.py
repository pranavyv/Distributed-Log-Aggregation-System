def parse_log(log_line):
    parts = log_line.strip().split("|", 3)

    if len(parts) != 4:
        raise ValueError(f"Invalid log format: {log_line!r}")

    timestamp, server, level, message = parts

    return {
        "timestamp": int(timestamp),
        "server": server,
        "level": level,
        "message": message,
    }
