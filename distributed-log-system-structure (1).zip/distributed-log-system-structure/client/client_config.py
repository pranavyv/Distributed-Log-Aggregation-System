import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent

SERVER_IP = os.getenv("LOG_SERVER_IP", "127.0.0.1")
PORT = int(os.getenv("LOG_SERVER_PORT", "9999"))
SERVER_NAME = os.getenv("LOG_SERVER_NAME", "client1")
TLS_CERT_FILE = os.getenv("LOG_TLS_CERT_FILE", str(BASE_DIR / "certs" / "server.crt"))

LOG_LEVELS = ["INFO", "WARNING", "ERROR"]
LOG_MESSAGES = [
    "User login",
    "API request",
    "Disk full",
    "Database connected",
    "Unauthorized access",
]

SEND_INTERVAL_SECONDS = float(os.getenv("LOG_SEND_INTERVAL_SECONDS", "0.5"))
RECONNECT_DELAY_SECONDS = 2.0
