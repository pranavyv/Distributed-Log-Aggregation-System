import random
import socket
import ssl
import time

from client.client_config import (
    LOG_LEVELS,
    LOG_MESSAGES,
    PORT,
    RECONNECT_DELAY_SECONDS,
    SEND_INTERVAL_SECONDS,
    SERVER_IP,
    SERVER_NAME,
    TLS_CERT_FILE,
)


def generate_log_line():
    timestamp = int(time.time())
    level = random.choice(LOG_LEVELS)
    message = random.choice(LOG_MESSAGES)
    return f"{timestamp}|{SERVER_NAME}|{level}|{message}"


def create_secure_socket():
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=TLS_CERT_FILE)
    context.check_hostname = False
    raw_socket = socket.create_connection((SERVER_IP, PORT), timeout=5)
    secure_socket = context.wrap_socket(raw_socket, server_hostname=SERVER_IP)
    secure_socket.settimeout(5)
    return secure_socket


def main():
    print(f"Secure log client started for {SERVER_NAME} -> {SERVER_IP}:{PORT}")

    while True:
        sock = None
        try:
            sock = create_secure_socket()
            print("TLS connection established.")

            while True:
                log_line = generate_log_line()
                sock.sendall(f"{log_line}\n".encode("utf-8"))
                print(f"Sent: {log_line}")
                time.sleep(SEND_INTERVAL_SECONDS)
        except KeyboardInterrupt:
            print("\nClient stopped.")
            break
        except (ConnectionError, OSError, ssl.SSLError) as exc:
            print(f"Connection issue: {exc}. Reconnecting in {RECONNECT_DELAY_SECONDS:.1f}s.")
            time.sleep(RECONNECT_DELAY_SECONDS)
        finally:
            if sock is not None:
                try:
                    sock.close()
                except OSError:
                    pass


if __name__ == "__main__":
    main()
